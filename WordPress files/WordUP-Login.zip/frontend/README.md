
-- React app frontend that displays UP login button

Use the React App src folder to build the project and place any configuration or build outputs into the relevant folders in this directory